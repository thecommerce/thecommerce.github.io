
NAME='ldap'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lldap']

GCC_LIST = ['ldap']

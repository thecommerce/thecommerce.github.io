
NAME='mongrel2'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lzmq']

GCC_LIST = ['mongrel2']

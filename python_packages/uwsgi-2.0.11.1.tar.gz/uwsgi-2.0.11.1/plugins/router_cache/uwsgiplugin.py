NAME='router_cache'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_cache']

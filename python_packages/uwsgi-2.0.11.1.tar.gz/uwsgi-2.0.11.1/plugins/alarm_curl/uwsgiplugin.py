NAME='alarm_curl'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lcurl']
GCC_LIST = ['alarm_curl_plugin']

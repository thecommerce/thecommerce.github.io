# This file is required to pretend sitemaps has models.
# Otherwise test models cannot be registered.
